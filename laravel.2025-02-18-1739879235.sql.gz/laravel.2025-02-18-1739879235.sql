-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (5,'Sentiment Analysis with Hugging Face and Gradio: A Simple Guide to Building a Text Classifier','In today’s data-driven world, understanding sentiment is crucial for analyzing customer feedback, social media conversations, and much more. Whether it\'s positive, negative, or neutral sentiment, extracting this information can reveal invaluable insights for businesses and individuals alike. In this blog post, we will walk you through how to build a Sentiment Analyzer using the power of Hugging Face’s transformers and Gradio for deploying the model.\r\n\r\nThis sentiment analyzer is capable of processing customer reviews stored in an Excel file, determining whether each review expresses a positive, negative, or neutral sentiment, and generating a summary chart of the sentiment distribution.\r\n\r\nHow It Works: An Overview\r\nThe application uses Hugging Face\'s pre-trained model for sentiment classification (distilbert-base-uncased-finetuned-sst-2-english). You upload an Excel file containing customer reviews, the sentiment of each review is analyzed, and a chart summarizing the sentiment distribution is generated. Additionally, you can download the results in a new file.\r\n\r\nLibraries and Tools Used\r\nHugging Face Transformers\r\nHugging Face has revolutionized NLP by providing easy access to state-of-the-art models like BERT, GPT-3, and many others. In our application, we are using the pre-trained model DistilBERT finetuned on the SST-2 dataset, which is designed for sentiment classification. The Hugging Face pipeline is an easy-to-use abstraction for applying models like this, enabling text classification tasks like sentiment analysis with just a few lines of code.\r\nGradio\r\nGradio is an amazing library that allows you to quickly create user-friendly interfaces for machine learning models. It enables you to deploy a model in a simple and interactive manner. With Gradio, users can upload files, interact with models, and visualize results all within a browser, making it perfect for this project where the end-users might not be familiar with code.\r\nPandas\r\nPandas is an essential library for handling data. We use it to read the Excel file containing reviews and manipulate the data frame before performing sentiment analysis. Pandas makes it easy to process and export the results.\r\nMatplotlib\r\nFor visualizing the sentiment analysis results, we use Matplotlib to create a pie chart of the sentiment distribution, helping users understand the sentiment breakdown at a glance.\r\nsentiment analyser\r\nDeploying on Hugging Face\r\nOnce the model and interface are created, Gradio makes it easy to deploy the sentiment analyzer on platforms like Hugging Face. By integrating the Gradio interface with the Hugging Face Spaces platform, users can interact with your model directly from a web interface without needing any additional setup.\r\n\r\nKey Features\r\nSentiment Classification: Identifies positive and negative sentiments in customer reviews.\r\nExcel File Support: Allows users to upload and process Excel files with ease.\r\nVisualization: Generates a sentiment distribution chart to give users an easy-to-understand summary.\r\nDownloadable Results: Users can download the processed results in an Excel file.\r\nConclusion\r\nThis project demonstrates the power of combining Hugging Face, Gradio, and Matplotlib to create a fully functioning sentiment analysis tool that is not only effective but also user-friendly. By leveraging pre-trained models and simple data processing tools, we were able to build a solution that can be used across various industries, including customer service, marketing, and research.\r\n\r\nDeploying it on Hugging Face Spaces makes it even more accessible, and Gradio provides an intuitive interface for anyone to use the model without writing a single line of code. You can try it out for yourself by visiting the following link: Sentiment Analyzer on Hugging Face.','images/9zaSAi82SKd6Ha6DDihstd5UK1OLD49IGTwwuE81.png','2025-02-18 11:38:55','2025-02-18 11:38:55'),(6,'Mastering Leave Management in Django: A Step-by-Step Guide to Building a Robust Leave Request System','In today\'s fast-paced work environment, managing employee leave requests efficiently is crucial for maintaining productivity and ensuring employee satisfaction. If you\'re a developer working with Django, building a leave management system can be a rewarding project that enhances your skills and provides value to your organization. In this blog, we\'ll walk you through the process of creating a robust leave request system using Django, complete with forms, views, templates, and role-based access control.\r\n\r\nWhy Build a Leave Management System?\r\nA leave management system allows employees to submit leave requests, which can then be reviewed and approved or rejected by managers or administrators. Key benefits include:\r\n\r\nStreamlined Processes: Automates the leave request and approval workflow.\r\n\r\nTransparency: Employees can track the status of their requests.\r\n\r\nRole-Based Access: Ensures that only authorized personnel can approve or reject requests.\r\n\r\nScalability: Easily adapts to the growing needs of your organization.','images/fw5fZFgmcPJNta8rYPNOxBsIMT1aYz3IB2E4DKCA.jpg','2025-02-18 11:41:14','2025-02-18 11:41:14');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2025_02_18_102201_create_blogs_table',2),(7,'2025_02_18_104608_create_posts_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('One-Liner Jokes','Dad Jokes','Animal Jokes') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (3,'Teacher: \"Agar tumhare paas 10 chocolates hain..','One-Liner Jokes','Teacher: \"Agar tumhare paas 10 chocolates hain aur main tumse 4 le loon, to tumhare paas kitni chocolates bachi?\"\r\nStudent: \"Teacher, mujhe lagta hai aapke paas bhi chocolates ki kami hai!\"','2025-02-18 11:43:10','2025-02-18 11:43:10'),(4,'Ek baar ek aadmi ne kaha','One-Liner Jokes','Ek baar ek aadmi ne kaha: \"Mujhe kaam karna pasand nahi hai.\" \r\nDost bola: \"Toh kaam kaise chalega?\" Aadmi: \"Main apne dimaag se kaam chalata hoon!\"','2025-02-18 11:44:28','2025-02-18 11:44:28');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Prashant Singh','info@thebitterreality.com',NULL,'$2y$10$rP9xcqvRFJE8/LdyYrLLue0VDMYlqze4JWOyacRFgb4JHSb5DSdw2',NULL,'2025-02-18 09:37:43','2025-02-18 09:37:43');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-18 11:47:15
